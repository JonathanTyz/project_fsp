<?php //buat ini sebagai UI untuk admin memilih ke admin_dosen.php atau admin_mahasiswa.php
?>

<!DOCTYPE html>
<html>
    <head>
        <title>Halaman Admin</title>
    </head>
    <body>
        <h2>Halaman Admin</h2>
        <p>Silakan pilih halaman yang ingin Anda lihat:</p>
        <ul>
            <li><a href="admin_dosen.php">Kelola Data Dosen</a></li>
            <li><a href="admin_mahasiswa.php">Kelola Data Mahasiswa</a></li>
        </ul>