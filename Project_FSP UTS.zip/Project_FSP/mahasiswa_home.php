<!DOCTYPE html>
<html>
<head>
    <title>MAHASISWA</title>
    <style>
        
    </style>
</head>
<body>
    <h2><b>Welcome mahasiswa</b></h2>
    Change Password: <button><a href="change_password.php">Change Password</a></button><br>
    Exit to Login:
    <button><a href="Login.php">EXIT</a></button>   
</body>
</html>