<!DOCTYPE html>
<?php
    require_once 'class/dosen.php';
?>
<html>
    <?php //Admin Kelola Data Dosen 
        $mysqli = new mysqli("localhost", "root", "", "fullstack");
    if ($mysqli->connect_error) {
        die("Failed to connect to MySQL: " . $mysqli->connect_error);
    }
    ?>
<head>
    <title>Kelola Dosen</title>
    <style>
        h2{
            text-align: center;
            margin-top: 30px;
            color: #333;
            font-size: 36px;
        }
        p{
            text-align: center;
            margin-top: 25px;
            color: #333;
            font-size: 20px;
        }
        table {
           width: 80%;
            margin: 20px auto;
        }
        th, td {
            border: 1px solid black; 
            padding: 8px;
            text-align: center;
        }
        th {
            background-color: #f2f2f2; 
        }
        #linkInsert{
            margin-left: 100px;
            padding: 8px;
        }
        #balikHome{
            margin-left: 100px;
            padding: 8px;
        }
        
    </style>
</head>
<body>
    <h2><b>Kelola Dosen</b></h2>
    <table>
        <thead>
            <thead>
            <tr>
                <th>Foto</th>
                <th>Nama</th>
                <th>NPK</th>
                <th colspan="2">Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php
            // Mendapatkan semau data dosen beserta fotonya dari database
                $PER_PAGE = 3;
                $dosen = new dosen();
                $cari = isset($_GET['cari']) ? $_GET['cari'] : '';
                $cari_persen = "%" . $cari . "%";
                $offset = isset($_GET['start']) ? (int)$_GET['start'] : 0;
                // agar tahu berapa data tiap halaman
                $res = $dosen->getDosen($cari_persen, $offset, $PER_PAGE);
                while($row = $res->fetch_assoc()) {
                    echo "<tr>";
                        // Tampilkan foto & data dosen
                        echo "<td> <img class = 'poster' src = 'image_dosen/" . $row['npk'] . "." . $row['foto_extension'] . "' width='100'></td>";
                        echo "<td>" . $row['nama'] . "</td>";
                        echo "<td>" . $row['npk'] . "</td>";
                        echo "<td>";
                            echo "<a href = 'admin_edit_dosen.php?npk=".$row['npk']."'>Edit</a>";
                        echo "</td>";
                        echo "<td>";    
                            echo "<a href='admin_delete_dosen.php?npk=".$row['npk']."'>Delete</a>";  
                        echo "</td>";
                    echo "</tr>";
                }
            ?>
        </tbody>
    </table>
    <p>
        <?php
        //dapat semua data dulu
        $res = $dosen->getDosen($cari_persen);
        // Hitung total data yang sesuai kriteria pencarian
        $total_data = $res->num_rows;
        $max_page = ceil($total_data / $PER_PAGE);
        for($page=1; $page <= $max_page; $page++) 
        {
            $offs = ($page - 1) * $PER_PAGE;
            echo "<a href='?start=$offs&cari=$cari'>$page</a> ";
        }
        ?>
    </p> <br>
    <a id='linkInsert' href = "admin_insert_dosen.php">Tambah Dosen</a>
    <a id = 'balikHome' href = "admin_home.php">Kembali ke home</a>

</body>
</html>