<?php
$mysqli = new mysqli("localhost", "root", "", "fullstack");
//yang diupdate hanya sesuai yang diisi jadi kalau kosong tidak ke overwrite data lama 
// (pakai input hidden lama di form admin_edit_mahasiswa.php)
$username = $_POST['username'];
$username_lama = $_POST['username_lama'];
$nrp = $_POST['nrp'];
$nama = $_POST['nama'];
$gender = $_POST['gender'];
$tanggal_lahir = $_POST['tanggal_lahir'];
$angkatan = $_POST['angkatan'];
$nrp_lama = $_POST['nrp_lama'];
$ext_lama = $_POST['ext_lama'];

$sql = "SELECT * FROM akun WHERE username = ?";
$stmt = $mysqli->prepare($sql);
$stmt->bind_param("s", $username);
$stmt->execute();
$res = $stmt->get_result();
if ($res->num_rows > 0 && $username_lama != $username) { //jika duplikat dan usernamenya bukan
    // username yang di edit maka, berhenti
        echo "Username sudah ada, silakan gunakan username lain.";
        echo "<br><a href='admin_mahasiswa.php'>Kembali ke halaman mahasiswa</a>";
        $stmt->close();
        $mysqli->close();
        exit;
}
else  { //kalau username tidak duplikat cek nrp juga

    $sql = "SELECT * FROM mahasiswa WHERE nrp = ?";
    $stmt = $mysqli->prepare($sql);
    $stmt->bind_param("s", $nrp);
    $stmt->execute();
    $res = $stmt->get_result();
    if ($res->num_rows > 0 && $nrp_lama != $nrp) { //jika duplikat (dan juga tidak 
        //sama dengan nrp lama user yang di edit), berhenti dilakukan agar tidak duplikat dengan user lain 
            echo "NRP sudah ada, silakan gunakan NRP lain.";
            echo "<br><a href='admin_mahasiswa.php'>Kembali ke halaman mahasiswa</a>";
            $stmt->close();
            $mysqli->close();
            exit;
    }
    else //jika NRP juga tidak duplikat baru di update di database
    // kalau foto ada foto lama dihapus diganti foto baru agar tidak duplikat
    {
        if (!empty($_FILES['foto']['name'])) 
        {
            $ext = strtolower(pathinfo($_FILES['foto']['name'], PATHINFO_EXTENSION));
            $sql = "UPDATE mahasiswa SET nrp = ?, nama = ?, gender = ?, tanggal_lahir = ?, angkatan = ?, foto_extention = ? WHERE nrp = ?";
            $stmt = $mysqli->prepare($sql);
            $stmt->bind_param("sssssss", $nrp, $nama, $gender, $tanggal_lahir, $angkatan, $ext, $nrp_lama);
            $stmt->execute();
            $stmt->close();
            $foto_baru = "image_mahasiswa/" . $nrp . "." . $ext;
            $foto_lama = "image_mahasiswa/" . $nrp_lama . "." . $ext_lama;
            if (file_exists($foto_lama)) 
            {
                unlink($foto_lama);
            }
            move_uploaded_file($_FILES['foto']['tmp_name'], $foto_baru); //simpan foto baru
        } 
        else 
        {
            // update tanpa foto, foto di folder di rename
            $sql = "UPDATE mahasiswa SET nrp = ?, nama = ?, gender = ?, tanggal_lahir = ?, angkatan = ? WHERE nrp = ?";
            $stmt = $mysqli->prepare($sql);
            $stmt->bind_param("ssssss", $nrp, $nama, $gender, $tanggal_lahir, $angkatan, $nrp_lama);
            $stmt->execute();
            $stmt->close();
            $foto_lama = "image_mahasiswa/" . $nrp_lama . "." . $ext_lama;
            $foto_baru = "image_mahasiswa/" . $nrp . "." . $ext_lama;
            if (file_exists($foto_lama)) 
            {
                rename($foto_lama, $foto_baru);
            }
        }        
        //update tabel akun juga kecuali password (diubah user sendiri admin cuma insert password)
        $sql = "UPDATE akun SET username = ?, nrp_mahasiswa = ? WHERE nrp_mahasiswa = ?";
        $stmt = $mysqli->prepare($sql);
        $stmt->bind_param("sss", $username, $nrp, $nrp_lama);
        $stmt->execute();

        $sql = "UPDATE akun SET username = ? WHERE nrp_mahasiswa = ?";
        $stmt = $mysqli->prepare($sql);
        $stmt->bind_param("ss", $username, $nrp); // pakai npk baru, karena cascade sudah jalan
        $stmt->execute();
    }

    }
        
$mysqli->close();

header("Location: admin_mahasiswa.php");
?>