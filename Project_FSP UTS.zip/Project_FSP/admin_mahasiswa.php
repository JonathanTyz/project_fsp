<!DOCTYPE html>
<html>
    <?php //Admin Kelola Data Dosen 
    require_once 'class/mahasiswa.php';
        $mysqli = new mysqli("localhost", "root", "", "fullstack");
    if ($mysqli->connect_error) {
        die("Failed to connect to MySQL: " . $mysqli->connect_error);
    }
    ?>
<head>
    <title>Kelola Mahasiswa</title>
    <style>
        h2{
            text-align: center;
            margin-top: 30px;
            color: #333;
            font-size: 36px;
        }
        p{
            text-align: center;
            margin-top: 25px;
            color: #333;
            font-size: 20px;
        }
        table {
           width: 80%;
            margin: 20px auto;
        }
        th, td {
            border: 1px solid black; 
            padding: 8px;
            text-align: center;
        }
        th {
            background-color: #f2f2f2; 
        }
        #linkInsert{
            margin-left: 100px;
            padding: 8px;
        }
        #balikHome{
            margin-left: 100px;
            padding: 8px;
        }
    </style>
</head>
<body>
    <h2><b>Kelola Mahasiswa</b></h2>
    <table>
        <thead>
            <thead>
            <tr>
                <th>Foto</th>
                <th>NRP</th>
                <th>Nama</th>
                <th>Gender</th>
                <th>Tanggal Lahir</th>
                <th>Angkatan</th>
                <th colspan="2">Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php
            // Mendapatkan semau data mahasiswa beserta fotonya dari database
                $PER_PAGE = 3;
                $mahasiswa = new mahasiswa();
                $cari = isset($_GET['cari']) ? $_GET['cari'] : '';
                $cari_persen = "%" . $cari . "%";
                $offset = isset($_GET['start']) ? (int)$_GET['start'] : 0;
                // agar tahu berapa data tiap halaman
                $res = $mahasiswa->getMahasiswa($cari_persen, $offset, $PER_PAGE);
                while($row = $res->fetch_assoc()) {
                    echo "<tr>"; //tampilkan foto mahasiswa
                        echo "<td> <img class = 'poster' src = 'image_mahasiswa/" . $row['nrp'] . "." . $row['foto_extention'] . "' width='100'></td>";
                        echo "<td>" . $row['nrp'] . "</td>";
                        echo "<td>" . $row['nama'] . "</td>";
                        echo "<td>" . $row['gender'] . "</td>";
                        echo "<td>" . $row['tanggal_lahir'] . "</td>";
                        echo "<td>" . $row['angkatan'] . "</td>";

                        echo "<td>";
                            echo "<a href = 'admin_edit_mahasiswa.php?nrp=".$row['nrp']."'>Edit</a>";
                        echo "</td>";
                        echo "<td>";    
                            echo "<a href='admin_delete_mahasiswa.php?nrp=".$row['nrp']."'>Delete</a>";  
                        echo "</td>";
                    echo "</tr>";
                }
            ?>
        </tbody>
    </table>
    <p>
        <?php
        //dapat semua data dulu
        $res = $mahasiswa->getMahasiswa($cari_persen);
        // Hitung total data yang sesuai kriteria pencarian
        $total_data = $res->num_rows;
        $max_page = ceil($total_data / $PER_PAGE);
        for($page=1; $page <= $max_page; $page++) 
        {
            $offs = ($page - 1) * $PER_PAGE;
            echo "<a href='?start=$offs&cari=$cari'>$page</a> ";
        }
        ?>
    </p> <br>
    <a id = 'linkInsert' href = "admin_insert_mahasiswa.php">Tambah Mahasiswa</a>
    <a id = 'balikHome' href = "admin_home.php">Kembali ke home</a>

</body>
</html>