<!DOCTYPE html>
<html>
<head>
    <title>Change Passowrd</title>
    <style>
        h2{
            text-align: center;
            margin-top: 30px;
            color: #333;
            font-size: 36px;
        }
        form {
            margin: auto;
            padding: 10px;
            background-color: #f9f9f9;
        }
        button {
            padding: 10px;
            color: black;
        }
    </style>
</head>
<body>
    <h2><b>Change Passowrd</b></h2>
        <form method="POST" action="change_password_proses.php" >
            <p><label>Old Password:</label> <br>
            <input name="old_password" required></p><br>
            <p><label>Password:</label><br>
            <input name="password" required></p><br>
            <button type="submit">Change Password</button>
        </form>
</body>
</html>