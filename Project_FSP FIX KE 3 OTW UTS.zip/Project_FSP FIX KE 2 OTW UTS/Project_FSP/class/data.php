<?php
define("SERVER", "localhost");
define("UID", "root");
define("PWD", "");
define("DB", "fullstack");
?>  