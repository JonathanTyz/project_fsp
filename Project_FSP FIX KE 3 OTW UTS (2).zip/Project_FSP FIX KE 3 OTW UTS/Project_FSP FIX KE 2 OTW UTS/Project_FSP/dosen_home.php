<?php
session_start();
if (!isset($_SESSION['user'])) 
    {
        header("Location: login.php");
        exit();
    }
?>
<!DOCTYPE html>
<html>
<head>
    <title>DOSEN</title>
    <style>
        body{
            font-family: 'Times New Roman', Times, serif;
            align-items: center;
            margin: 0;
        }
        .isi{
            background-color: white;
            padding: 30px 40px;
            text-align: center;
            width: 400px;
            border: 10px solid #333;
        }
        button{
            width: 200px;
            background-color: #ffffffff;
            color: white;
            padding: 10px;
            margin: 10px;
            font-weight: bold;
        }
    </style>
</head>
<body>
    <div class = 'isi'>
        <h2><b>Welcome <?php echo $_SESSION['user']['username']; ?></b></h2>
        <h4><b>Role: Dosen</b></h4>
        Change Password: <br><button><a href="change_password.php">Change Password</a></button><br>
        Exit to Login: <br>
        <button><a href="logout.php">EXIT</a></button>
    </div>
</body>
</html>